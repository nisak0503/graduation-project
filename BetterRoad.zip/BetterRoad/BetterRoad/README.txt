Main
ViewController.swift      | main function

Others
Hazard.swift              | hazard class 
HazardManager.swift       | load hazard
Task.swift                | one source -> destination task

LoginViewController.swift | envoke once press login, to be continued

final_gps.txt             | time and coordinates
dataPreProcessing.cpp     | cpp program to precess .txt into .plist
Info.plist                | hazard information  

